document.addEventListener("DOMContentLoaded", () => {
  const form = document.getElementById("article-form");
  const messageEl = document.getElementById("form-message");

  if (!form) return;

  form.addEventListener("submit", async (e) => {
    e.preventDefault();
    messageEl.textContent = "Enviant...";
    messageEl.style.color = "#e5e7eb";

    const title = document.getElementById("title").value.trim();
    const content = document.getElementById("content").value.trim();

    if (!title || !content) {
      messageEl.textContent = "Tots els camps són obligatoris.";
      messageEl.style.color = "#f97373";
      return;
    }

    try {
      const res = await fetch("https://api.local/api/articles", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ title, content, user_id: 1 }),
      });

      const data = await res.json();

      if (!res.ok) {
        throw new Error(data.error || "Error al crear l'article");
      }

      messageEl.textContent = "Article creat correctament!";
      messageEl.style.color = "#4ade80";
      form.reset();
    } catch (err) {
      console.error(err);
      messageEl.textContent = "No s'ha pogut crear l'article.";
      messageEl.style.color = "#f97373";
    }
  });
});
