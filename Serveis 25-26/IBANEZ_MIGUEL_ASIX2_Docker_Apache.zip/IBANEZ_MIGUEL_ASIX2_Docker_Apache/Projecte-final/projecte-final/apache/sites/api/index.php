<?php
/**
 * Frontend principal - frontend.local
 * Mostra estadístiques de visites (Redis) i articles (MySQL)
 */

// Configuracio de la base de dades
$dbHost = getenv('MYSQL_HOST') ?: 'mysql';
$dbName = getenv('MYSQL_DATABASE') ?: 'projecte_final';
$dbUser = getenv('MYSQL_USER') ?: 'project_user';
$dbPass = getenv('MYSQL_PASSWORD') ?: 'project_pass_secure_2024';

// Configuracio Redis
$redisHost = getenv('REDIS_HOST') ?: 'redis';

$visites = 0;
$articles = [];
$totalUsers = 0;
$totalArticles = 0;

// Connexio a Redis i increment de visites
try {
    $redis = new Redis();
    $redis->connect($redisHost, 6379);
    // Incrementar el comptador de visites
    $visites = $redis->incr('page_views_frontend');
} catch (Exception $e) {
    // Si Redis no està disponible, continuar sense comptador
    $visites = 0;
}

// Connexio a MySQL
try {
    $dsn = "mysql:host={$dbHost};dbname={$dbName};charset=utf8mb4";
    $pdo = new PDO($dsn, $dbUser, $dbPass, [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    ]);

    // Obtenir els últims 5 articles
    $stmt = $pdo->query("
        SELECT a.id, a.title, a.content, a.published_at, u.username
        FROM articles a
        JOIN users u ON a.user_id = u.id
        ORDER BY a.published_at DESC
        LIMIT 5
    ");
    $articles = $stmt->fetchAll();

    // Obtenir estadistiques
    $totalUsers = $pdo->query("SELECT COUNT(*) FROM users")->fetchColumn();
    $totalArticles = $pdo->query("SELECT COUNT(*) FROM articles")->fetchColumn();

} catch (Exception $e) {
    $articles = [];
}
?>
<!DOCTYPE html>
<html lang="ca">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="Projecte Final Docker - Frontend amb estadístiques i articles">
    <title>Projecte Final - frontend.local</title>
    <link rel="stylesheet" href="/assets/css/style.css">
</head>

<body>
    <header>
        <h1>Projecte Final - frontend.local</h1>
        <p class="subtitle">Stack Docker Compose amb Apache, MySQL, Redis i phpMyAdmin</p>
    </header>

    <main>
        <section class="card">
            <h2>Estadistiques</h2>
            <div class="stats-grid">
                <div class="stat-item">
                    <span class="stat-value"><?php echo htmlspecialchars($visites); ?></span>
                    <span class="stat-label">Visites (Redis)</span>
                </div>
                <div class="stat-item">
                    <span class="stat-value"><?php echo htmlspecialchars($totalUsers); ?></span>
                    <span class="stat-label">Usuaris</span>
                </div>
                <div class="stat-item">
                    <span class="stat-value"><?php echo htmlspecialchars($totalArticles); ?></span>
                    <span class="stat-label">Articles</span>
                </div>
            </div>
        </section>

        <section class="card">
            <h2>Ultims 5 Articles</h2>
            <?php if (empty($articles)): ?>
                <p class="no-data">No hi ha articles disponibles.</p>
            <?php else: ?>
                <ul class="articles">
                    <?php foreach ($articles as $article): ?>
                        <li>
                            <h3><?php echo htmlspecialchars($article['title']); ?></h3>
                            <small>
                                Per <strong><?php echo htmlspecialchars($article['username']); ?></strong>
                                el <?php echo htmlspecialchars($article['published_at']); ?>
                            </small>
                            <p><?php echo nl2br(htmlspecialchars($article['content'])); ?></p>
                        </li>
                    <?php endforeach; ?>
                </ul>
            <?php endif; ?>
        </section>

        <section class="card">
            <h2>Crear Nou Article</h2>
            <form id="article-form">
                <div class="form-group">
                    <label for="title">Títol:</label>
                    <input type="text" id="title" name="title" required placeholder="Escriu el títol de l'article">
                </div>
                <div class="form-group">
                    <label for="content">Contingut:</label>
                    <textarea id="content" name="content" rows="4" required
                        placeholder="Escriu el contingut de l'article"></textarea>
                </div>
                <button type="submit">Publicar Article</button>
                <p id="form-message" class="message"></p>
            </form>
        </section>
    </main>

    <footer>
        <p>Projecte Final - ASIX2 - Docker Compose Stack</p>
        <p><a href="https://api.local/api/articles" target="_blank">API REST</a> |
            <a href="http://localhost:8080" target="_blank">phpMyAdmin</a>
        </p>
    </footer>

    <script src="/assets/js/app.js"></script>
</body>

</html>