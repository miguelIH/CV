---

Repte 1:

---

Comandes prèvies:
<img width="886" height="513" alt="image" src="https://github.com/user-attachments/assets/f43933bf-4e14-4919-9aae-c4929595f05d" />

<br>

<img width="886" height="513" alt="image" src="https://github.com/user-attachments/assets/0a47178a-f330-4e89-be35-dd204b2233b4" />

<br>

<img width="886" height="513" alt="image" src="https://github.com/user-attachments/assets/2721390b-9dee-4589-b9fe-a57ecf0fe81e" />

<br>

<img width="886" height="533" alt="image" src="https://github.com/user-attachments/assets/a05c137c-0524-43ee-9e42-1ad47d441460" />

1.1

Amb la primera comanda podrem veure  el directori complet de la instal·lació de apache (httpd), en la següent comanda igual però amb la carpeta conf. 
I en la tercera comanda, ens diu que el document root es troba a la ruta “/usr/local/apache2/htdocs”

<br>

<img width="886" height="513" alt="image" src="https://github.com/user-attachments/assets/0b4af663-a668-46b8-8bc0-45050ce34879" />

<br>

2.4

<br>

<img width="886" height="221" alt="image" src="https://github.com/user-attachments/assets/7ef4970f-f997-4622-94f9-e31ea7c0c834" />

<br>

<img width="886" height="43" alt="image" src="https://github.com/user-attachments/assets/ab78eca8-8c27-4b70-aa40-e9ae8da42de4" />

<br>

<img width="886" height="445" alt="image" src="https://github.com/user-attachments/assets/61b23d4d-7dcf-46ca-87df-3442e0890d84" />

<br>

2.5

<img width="886" height="463" alt="image" src="https://github.com/user-attachments/assets/d73cb582-c5b5-4e08-b4df-b95ae241a43a" />


<img width="886" height="256" alt="image" src="https://github.com/user-attachments/assets/f090e429-747f-4c92-a9a4-5c4f359e3d82" />

<img width="886" height="475" alt="image" src="https://github.com/user-attachments/assets/e66abaf9-1b88-4e24-a659-c07a3562cdf8" />

3.3
(ip maquina virtual)
<br>

<img width="886" height="259" alt="image" src="https://github.com/user-attachments/assets/c1c7c973-bd02-49a6-b72f-c6e0d4b887e9" />

3.4

<img width="886" height="445" alt="image" src="https://github.com/user-attachments/assets/0425fdc4-9a54-4225-8b8f-23719bedbec7" />

<img width="886" height="217" alt="image" src="https://github.com/user-attachments/assets/aff680e9-7b45-45d1-992a-69728690a8b1" />

Dockerignore

<img width="886" height="471" alt="image" src="https://github.com/user-attachments/assets/44ffd3ff-4e06-4e5b-816c-935259b47c14" />

---

Repte 2:

---

Primer de tot haurem de crear el directori, ho farem 
<br>
<img width="886" height="348" alt="image" src="https://github.com/user-attachments/assets/a32dab07-57e5-41ce-911e-2d304b825a5b" />
<br>
<img width="886" height="41" alt="image" src="https://github.com/user-attachments/assets/6fa63537-9802-4239-872b-3d2a922ed52b" />
<br>
<img width="901" height="643" alt="image" src="https://github.com/user-attachments/assets/ff817410-628c-4bc5-be66-bca21ee099ce" />
<br>
<img width="886" height="520" alt="image" src="https://github.com/user-attachments/assets/4cb945cf-63bc-4f3c-bb5d-bd9744cf0f84" />
<br>
<img width="886" height="244" alt="image" src="https://github.com/user-attachments/assets/f8a1cd3a-2eec-4788-8e31-dafdde4d56bd" />
<br>
<img width="886" height="593" alt="image" src="https://github.com/user-attachments/assets/fb597bb7-53e1-477d-bbb6-71cfbb514d22" />
<br>
Com que ja l’havia executat anteriorment durant les proves, Docker em retorna el missatge següent indicant que el contenedor ja existeix:
<br>
<img width="886" height="108" alt="image" src="https://github.com/user-attachments/assets/27942a9a-1296-4279-89e3-565581ecc08b" />
<br>
<img width="886" height="543" alt="image" src="https://github.com/user-attachments/assets/ca1e5bc5-081f-4b91-bef2-7867506822da" />
<br>
<img width="886" height="558" alt="image" src="https://github.com/user-attachments/assets/99b304dc-7c36-4c4b-8ef2-eed231e7f5b1" />
<br>
<img width="886" height="553" alt="image" src="https://github.com/user-attachments/assets/091495cd-2c38-453e-9084-1ddba0602d46" />
<br>

---

Repte 3

---

Estructura:

<br>
<img width="886" height="352" alt="image" src="https://github.com/user-attachments/assets/ee26a4a5-de71-4f3f-bee8-6ef2a4a53bf6" />
<br>
Fitxers:
<br>
<img width="886" height="547" alt="image" src="https://github.com/user-attachments/assets/bf18d9ed-c2fa-4d13-a44e-a95a39c6e5d9" />
<br>
Construcció de la imatge
<br>
<img width="886" height="299" alt="image" src="https://github.com/user-attachments/assets/0996098e-1025-4124-b15b-8c3f89a43a88" />
<br>
<img width="886" height="43" alt="image" src="https://github.com/user-attachments/assets/d4220822-3037-4ef2-bab8-251d47bfd602" />
<br>
Execució del contenidor:

<br>

<img width="886" height="664" alt="image" src="https://github.com/user-attachments/assets/d2c9d785-2295-4e88-84fd-ffc0c64307c2" />

<br>

Captures curl:

<img width="886" height="238" alt="image" src="https://github.com/user-attachments/assets/15e1d1d3-4aa2-447f-a93e-1cd19f33122d" />
<br>
<img width="886" height="557" alt="image" src="https://github.com/user-attachments/assets/1228633f-9231-4f66-af88-742a4a91e8b8" />
<br>

---
Repte 4:
---
Estructura:
<br>

<img width="886" height="367" alt="image" src="https://github.com/user-attachments/assets/cebd5a49-e40c-449e-aad5-5a73492aded2" />

<br>

<img width="886" height="435" alt="image" src="https://github.com/user-attachments/assets/e1d76c1a-e5cd-4ad9-b6c4-a3fa3ff9589c" />

<br>

<img width="886" height="432" alt="image" src="https://github.com/user-attachments/assets/54422cd7-1981-4065-961c-dff541307a6c" />

<br>

<img width="886" height="203" alt="image" src="https://github.com/user-attachments/assets/d3d9b331-5c4b-4f7d-a3cb-886ed26e6a55" />

<br>

<img width="886" height="52" alt="image" src="https://github.com/user-attachments/assets/29d4420c-b628-4e88-81f2-eb6f6311871d" />

<br>
  
<img width="886" height="461" alt="image" src="https://github.com/user-attachments/assets/e21a403d-5f1c-463b-ad46-8dc156ca6c9e" />

<br>

<img width="886" height="331" alt="image" src="https://github.com/user-attachments/assets/a7c19b44-6431-4ea8-bbfb-c1a0a8e6a542" />

<br>

Comandes fetes desde un usuari sense privilegis.

<br>

<img width="886" height="365" alt="image" src="https://github.com/user-attachments/assets/d3ef6dfe-a332-4dce-b3bf-d58c433b4980" />

<br>

Logs:

<img width="886" height="401" alt="image" src="https://github.com/user-attachments/assets/1e1d0ae6-62b4-423c-9716-ac9a91ceb3d3" />

---

Repte 5:

---

Estructura:

<br>

<img width="886" height="237" alt="image" src="https://github.com/user-attachments/assets/82dcca72-7982-4ee5-817a-bcdfd357b603" />

<br>

Dockerfile

<br>

<img width="886" height="324" alt="image" src="https://github.com/user-attachments/assets/9df38a2b-6200-4c25-a286-696fecfecedc" />

<br>

Index.php:

<br>

<img width="886" height="82" alt="image" src="https://github.com/user-attachments/assets/f6c8fc58-0fdc-4fb2-87ec-1ae1b879dcf8" />

<br>

Dockercompose.yml:

<br>

<img width="886" height="465" alt="image" src="https://github.com/user-attachments/assets/fa6c6751-671b-483a-bc09-f7d9a0398a72" />

<br>

<img width="886" height="200" alt="image" src="https://github.com/user-attachments/assets/16aeb8e8-4e44-4629-8679-4610bfafb618" />

<br>

<img width="886" height="470" alt="image" src="https://github.com/user-attachments/assets/5f15423a-45c9-4bc6-9639-f13fd92eb928" />

<br>

<img width="886" height="472" alt="image" src="https://github.com/user-attachments/assets/6088197e-4d97-490b-a2ba-3fed4ce3960d" />

<br>

Ara poso la nova informació de redis de la següent manera:

<br>

<img width="886" height="470" alt="image" src="https://github.com/user-attachments/assets/0e8d33b5-99bc-468e-8933-f8241cb24e05" />

<br>

Faig lo mateix amb el Dockerfile:

<br>

<img width="886" height="221" alt="image" src="https://github.com/user-attachments/assets/87104de3-007d-4bf2-8acc-79ebbe47b255" />

<br>

<img width="886" height="464" alt="image" src="https://github.com/user-attachments/assets/ab133c19-4c12-4300-8dd7-dced1c5a58dc" />

<br>

Modifiquem aquest artixu:

<br>

<img width="886" height="464" alt="image" src="https://github.com/user-attachments/assets/eb7f0b39-cc47-481d-ae19-5283ac1e9700" />

<br>

<img width="886" height="469" alt="image" src="https://github.com/user-attachments/assets/14c477be-0d7e-4196-9556-aac785a8b07b" />

<br>

<img width="886" height="462" alt="image" src="https://github.com/user-attachments/assets/b4b200d7-7fba-4c8b-841f-7168fa59f267" />

Ho aixequem:

<br>

<img width="886" height="468" alt="image" src="https://github.com/user-attachments/assets/3ef78221-1b1e-4107-95d5-e540e1c6bbbd" />

<br>

<img width="886" height="464" alt="image" src="https://github.com/user-attachments/assets/098da757-8712-479d-af3b-0e3b696cee63" />

<br>

<img width="886" height="109" alt="image" src="https://github.com/user-attachments/assets/4a172f1e-020f-4479-8525-3c9e01062079" />

<br>

<img width="886" height="51" alt="image" src="https://github.com/user-attachments/assets/7e084b15-e7d8-4a52-a588-eea57a5afcd5" />

<br>

<img width="886" height="461" alt="image" src="https://github.com/user-attachments/assets/372029fe-a112-4a39-9847-0726d60a1edc" />

<br>

<img width="886" height="470" alt="image" src="https://github.com/user-attachments/assets/a9802b66-2565-4dc1-8cfd-828abc7e317c" />

<br>

<img width="886" height="98" alt="image" src="https://github.com/user-attachments/assets/89b53491-35bc-4dcc-a595-de32da543925" />

---

Autor: **Miguel Ibañez Hernando (ASIX2)**  Mòdul: **M0375 – Administració de Sistemes Operatius / Docker & Apache**  






