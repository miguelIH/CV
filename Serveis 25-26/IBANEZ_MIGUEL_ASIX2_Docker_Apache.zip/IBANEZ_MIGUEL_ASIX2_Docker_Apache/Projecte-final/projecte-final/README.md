# <p align="center"> Projecte Final </p>
# <p align="center"> Stack Docker amb Apache, MySQL, Redis i phpMyAdmin </p>
---
<br>

Aquest projecte és la unitat de Docker + Apache.  
L’objectiu és muntar una aplicació web completa utilitzant **Docker Compose**, amb:

- Un servidor **Apache httpd** amb dos Virtual Hosts (`frontend.local` i `api.local`)
- Una base de dades **MySQL 8.0.35**
- Un servei de **Redis** per comptar visites
- **phpMyAdmin** per administrar la base de dades
- Certificats **HTTPS auto-signats**
- **Logs en format JSON** muntats a l’host

---
<br>

# 1. Arquitectura del sistema
Doncs aquesta es la meva estructura:

```text
projecte-final/
├── docker-compose.yml
├── apache/
│   ├── Dockerfile
│   ├── conf/
│   │   ├── httpd.conf
│   │   └── vhosts/
│   │       ├── frontend.conf
│   │       └── api.conf
│   ├── certs/
│   │   ├── server.crt
│   │   └── server.key
│   └── sites/
│       ├── frontend/
│       │   ├── index.php
│       │   └── assets/
│       │       ├── css/style.css
│       │       └── js/app.js
│       └── api/
│           └── index.php
├── mysql/
│   └── init/
│       └── 01-schema.sql
├── redis/
├── logs/
   ├── access.json
   ├── api_access.json
   ├── api_error.log
   ├── frontend_access.json
   └── frontend_error.log
```
<img width="801" height="682" alt="1" src="https://github.com/user-attachments/assets/8b64e4b1-853a-4aae-becd-b8386deb18b0">

---

# 2 Desplegament del stack 

---

2.1 Inicialitzem els serveis
De moment només mostrare la captura amb la verificació de tots el serveis funcionant, per fer-ho executo aquesta comanda:
```
docker compose up -d
```
<img width="567" height="116" alt="2" src="https://github.com/user-attachments/assets/4f4f68d3-2989-402f-ac32-5aeb44485635" />

Seguidament comprovo l'estat amb aquesta:
```
docker ps
```
<img width="1919" height="468" alt="3" src="https://github.com/user-attachments/assets/2a53422d-9a78-4b2a-9666-7273edb8b849" />
2.2 Configuració de /etc/hosts
Ara per resoldre aquests dominis locals, haig de configurar el etc/hosts, per fer-ho poso aquesta comanda:
<br>
```
nano etc/hosts
```
<br>
Hauria de quedar d'aquesta manera:
<br>
<img width="567" height="113" alt="4" src="https://github.com/user-attachments/assets/a82630f3-34d6-4219-b3c3-a172150d7911" />

---

# 3. Serveis i funcionalitats

-----

3.1 Frontend amb HTTPS
<br>
Captura demostrant el autosignat:
<br>
<img width="886" height="557" alt="image" src="https://github.com/user-attachments/assets/e7e54383-6466-4911-a83d-7fc43ad30446" />
<br>
Seguidament el contingut es:
<br>
<img width="1273" height="725" alt="image" src="https://github.com/user-attachments/assets/b89c11b8-7518-46ae-b6b1-9ca2f58173dd" />
<br>
I ara mostro el contingut del certificate:
<img width="886" height="551" alt="image" src="https://github.com/user-attachments/assets/a1924c31-5c51-4c18-b2ba-5ebb68bdfb9e" />
<br>
---
3.2 Api rest
Primer de tot quan entro per navegador em surt el auto-signat:
<br>
<img width="1281" height="798" alt="image" src="https://github.com/user-attachments/assets/0a79fffe-06d4-423a-9ab1-6f65e5e2eeea" />
<br>
Contingut del api:
<img width="1274" height="470" alt="image" src="https://github.com/user-attachments/assets/276be884-bd2a-4e21-a515-147098d730c3" />
<br>
---
3.3 Redireccio Http a https
Amb la següent comanda mostro com fa la redireccio:
<br>
<img width="886" height="139" alt="image" src="https://github.com/user-attachments/assets/c5e97870-3b1d-44fb-b6e9-25a0c65aa6cc" />
<br>
Faig lo mateix amb el api:
<img width="886" height="164" alt="image" src="https://github.com/user-attachments/assets/6f969058-de00-4a60-b6db-ffc74e8b13a2" />
<br>
---
3.4. Capçaleres de seguretat
Als Virtual Hosts he afegit diverses capçaleres:
- X-Frame-Options: SAMEORIGIN
- X-Content-Type-Options: nosniff
- Referrer-Policy: no-referrer-when-downgrade
- Content-Security-Policy: default-src 'self';
Es veuen a la sortida del curl -I anterior, a més he configurat capçalares en el httpd.conf
<img width="1919" height="527" alt="image" src="https://github.com/user-attachments/assets/1206d950-8169-429a-a978-f1a8e8183ff3" />
<br>
---
<br>
3.5 MySQL: esquemes i dades inicials
En la meva estructura tinc les carpetes mysql/init/01-schema.sql, aquest script crea la base de dades projecte_final amb dues taules:

```
users (id, username, email, created_at)
articles (id, user_id, title, content, published_at)
````
Primer de tot mostro com es en web:
<br>
<img width="886" height="554" alt="image" src="https://github.com/user-attachments/assets/cec2bf22-f898-40db-af44-556a62bfe0e1" />
<br>
Seguidament mostro procediment fet amb consola:
<img width="704" height="641" alt="image" src="https://github.com/user-attachments/assets/9c2f5ba6-c6b6-478f-a8d0-c0c0f7704c95" />
<br>
<img width="952" height="158" alt="image" src="https://github.com/user-attachments/assets/5d2db2b1-8e53-4292-99fa-fb9ac65d8245" />
<br>
En la meva configuració del docker-compose.yml tinc el següent, doncs per la configuració que faig server PMA-HOST, PMA-USER, PMA-PASSWORD quan vaig al navegador web entrar automàticament amb aquestes credencials
<br>
<img width="886" height="475" alt="image" src="https://github.com/user-attachments/assets/5be119bc-c6f2-447e-9115-6c14adbe0ca0" />
<br>
---
<br>
3.6. Redis: comptador de visites
Per demostrar-ho adjunto les següentes captures:
<br>
<img width="1085" height="99" alt="image" src="https://github.com/user-attachments/assets/3a26f972-98ad-482a-a5af-aa548a583f90" />
<br>
3.7 PhpMyAdmin
phpMyAdmin s’exposa al port 8080 de l’host i està connectat al servei MySQL del docker-compose.
Al fitxer docker-compose.yml el servei té, entre altres, la configuració:
<br>
<img width="579" height="341" alt="image" src="https://github.com/user-attachments/assets/e81c34b2-be93-4b0f-a234-241ab9c9214a" />
<br>
<img width="1277" height="796" alt="image" src="https://github.com/user-attachments/assets/ad913d91-fde5-407c-947d-14f83dc9fb10" />

---

# 4. Logs Apache

---

4.1 Logs access
Els accessos als Virtual Hosts mostren la IP 172.18.0.1 perquè Apache rep totes les peticions a través de la xarxa interna de Docker, després quan posa 304 es que es correcta la connexió.
<br>
<img width="886" height="355" alt="image" src="https://github.com/user-attachments/assets/8e32908d-d9db-4e84-b740-a5c6f918533a" />
<br>
4.2 Logs d’error:
En aquests logs ens diuen que el certificat es auto-signat.
<br>
<img width="1017" height="177" alt="image" src="https://github.com/user-attachments/assets/f3b4e0d7-a14e-4ca3-ae37-595645ee38f8" />























Autor: **Miguel Ibañez Hernando (ASIX2)**  Mòdul: **M0375 – Administració de Sistemes Operatius / Docker & Apache**  

























