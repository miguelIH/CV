CREATE DATABASE IF NOT EXISTS projecte_final
  CHARACTER SET utf8mb4
  COLLATE utf8mb4_unicode_ci;

USE projecte_final;

-- Taula d'usuaris
CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL UNIQUE,
    email VARCHAR(100) NOT NULL UNIQUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Taula d'articles
CREATE TABLE IF NOT EXISTS articles (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    title VARCHAR(255) NOT NULL,
    content TEXT NOT NULL,
    published_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_articles_user
      FOREIGN KEY (user_id) REFERENCES users(id)
      ON DELETE CASCADE
);

-- Usuaris
INSERT INTO users (username, email) VALUES
  ('miguelibanez1', 'miguelibanez1@example.com'),
  ('miguelibanez2', 'miguelibanez2@example.com'),
  ('miguelibanez3', 'miguelibanez3@example.com');

-- Articles
INSERT INTO articles (user_id, title, content) VALUES
  (1, 'Introduccio a Docker Compose', 'Docker Compose permet definir i executar aplicacions multi-contenidor de forma senzilla.'),
  (1, 'Configuracio de Virtual Hosts', 'Els virtual hosts permeten servir multiples llocs web des dun mateix servidor Apache.'),
  (2, 'MySQL i persistencia de dades', 'Els volums de Docker garanteixen que les dades de MySQL es mantinguin entre reinicis.'),
  (2, 'Redis com a sistema de cache', 'Redis emmagatzema dades en memoria per accelerar les consultes mes frequents.'),
  (3, 'Seguretat amb HTTPS', 'Els certificats SSL xifren la comunicacio entre el navegador i el servidor.');
